const blogContent=[
  {time:"2016.09.09",title:"资产",content:"固定资产税务在中小企业中的法规"},
  {time:"2016.06.14",title:"税务、会计",content:"固定资产税务在中小企业中的法规"},
  {time:"2016.05.17",title:"税务、会计",content:"固定资产税务在中小企业中的法规"},

]
ReactDOM.render(
  <div className="main-box">
    <div className="hero">
      <div className="hero-left-box"></div>
      <div className="hero-right-box">
        <div className="right-box-title">实验5 CSS定位高级练习</div>
        <div className="right-box-content">你有没有想过，为什么我们要有这么多技术来隐藏元素，而它们看起来都实现的是同样的效果？每一种方法实际上与其他方法之间都有一些细微的不同，这些不同决定了在一个特定的场合下使用哪一个方法。</div>
        <div className="learn-more">
          Learn More
        </div>
      </div>
    </div>
    <div className="blog">
      <div className="blog-hero">
        <div className="blog-titles">
          <div className="blog-title">Blog</div>
          <div className="blog-subtitle">这是副标题</div>
        </div>
        <div className="blog-more-box">
          <div className="blog-more">
            Learn More
          </div>
        </div>
      </div>
      <div className="hr"/>
      <div className="blog-box">
        {blogContent.map((value,index)=>{
          console.log(value)
          return (<div key={index} className="blog-item">
              <div className="blog-content-time">{value.time}</div>
              <div className="blog-content-tag-box">
                <div className="blog-content-tag-item">
                  {value.title}
                </div>
              </div>
              <div className="blog-content-content">{value.content}</div>
          </div>)
        })}
        
      </div>
      <div className="bottom">
        <div className="bottom-box">
          <div className="bottom-title">电话咨询合作</div>
          <div className="bottom-content-box">
            <div className="content-box-title">电话号码为</div>
            <div className="content-box-number">06-6121-6103</div>
            <div className="content-box-detail">一些沟通细节、一些沟通细节、一些沟通细节</div>
            <div className="work-time">工作时间为 9：00~18：00</div>

          </div>
        </div>
        <div className="bottom-box">
        <div className="bottom-title">web咨询合作</div>
          <div className="bottom-content-box">
            <div className="email-box">
              邮件联系我们公司方式
            </div>
            <div className="email-detail">
              email的合作方式是24小时在线的一种形式，可以随时进行沟通。
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>,

  document.getElementById('root')
)