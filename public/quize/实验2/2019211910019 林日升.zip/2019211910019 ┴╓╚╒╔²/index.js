const navItem = ["Home", "ONEZERO", "Two", "three", "four", "five", "five", "five", "five"]
const leftBox = [
    { title: "commonly", subTitle: "popular medium" },
    { title: "commonly", subTitle: "popular medium" },
    { title: "commonly", subTitle: "popular medium" },]
const rightBox = [
    { title: "commonly", subTitle: "popular medium" },
    { title: "commonly", subTitle: "popular medium" },
    { title: "commonly", subTitle: "popular medium" },
]
ReactDOM.render(
    <div>
        <div className="nav">
            {
                navItem.map((value, index) => {
                    return <span key={index} className="nav-item">{value}</span>
                })
            }
        </div>
        <div className="content">
            <div className="left-page">
                {
                    leftBox.map((value, index) => {
                        return (
                            <div key={index} className="left-box">
                                <div className="sub-title">{value.subTitle}</div>
                                <div className="title">{value.title}</div>
                                <div className="sub-title">{value.subTitle}</div>
                                <div className="sub-title">{value.subTitle}</div>
                                <div className="show-more">showMore</div>

                            </div>
                        )
                    })
                }
            </div>
            <div className="right-page">
                <div className="right-title">
                    popular on medium
                    <hr />
                </div>
                <div className="right-box-content">
                    <div className="right-box-index">此处放置index</div>
                    <div className="right-box-content-content">
                        {
                            rightBox.map((value, index) => {
                                return (
                                    <div key={index} className="right-box">
                                        <div className="title">{value.title}</div>
                                        <div className="sub-title">{value.subTitle}</div>
                                        <div className="sub-title">{value.subTitle}</div>
                                        <div className="sub-title">{value.subTitle}</div>
                                    </div>
                                )
                            })
                        }
                    </div>
                </div>

            </div>
        </div>
    </div>,
    document.getElementById('root')
);