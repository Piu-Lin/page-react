class App extends React.Component {
    state={
        change:0
    }
    render() {
        const product = [1,2,3,4,5,6]
        return (<div className="index-box">
            <div onClick={()=>{this.setState({change:1})}}>第一个</div>
            <div onClick={()=>{this.setState({change:2})}}>第二个</div>
            <div onClick={()=>{this.setState({change:3})}}>第三个</div>

            {this.state.change==1?(
                <div className="one-box">
                <div className="nav">
                    <div className="nav-left">
                    <div className="nav-item nav-first-item"/>
                    <div className="nav-item"/>
                    <div className="nav-item"/>
                    <div className="nav-item"/>
                    </div>
                    <div className="nav-right">
                    <div className="nav-item nav-last-item"/>
                    </div>
                </div>
                <div className="container">
                    <div className="con-left">
                        <div className="con-left-top"></div>
                        <div className="con-left-bottom">
                        <div className="con-bottom-item"/>
                        <div className="con-bottom-item"/>
                        <div className="con-bottom-item"/>
                        </div>
                    </div>
                    <div className="con-right">
                    <div className="con-right-item"/>
                    <div className="con-right-item"/>
                    <div className="con-right-item"/>
                    <div className="con-right-item"/>
                    <div className="con-right-item"/>
                    <div className="con-right-item"/>
                    <div className="con-right-item"/>
                    <div className="con-right-item"/>
                    </div>
                </div>
                </div>
            ):""}
            {this.state.change==2?(
                <div className="two-box">
                    <div className="box-bottom">
                        <div className="item-title">标题文字</div>
                        <div className="item-detail">细节信息</div>
                        <div className="price">
                            <div className="price-left">
                                <div className="price-true">实际价格</div>
                                <div className="price-fake">原价:299</div>
                            </div>
                            <div className="price-right">xxx已售</div>
                        </div>
                    </div>
                </div>
            ):""}
            {this.state.change==3?(
                <div className="product-box">
                {product.map((value,index)=>{
                    return (
                            <div key={index} className="three-box">
                                <div className="box-bottom">
                                    <div className="item-title">标题文字</div>
                                    <div className="item-detail">细节信息</div>
                                    <div className="price">
                                        <div className="price-left">
                                            <div className="price-true">实际价格</div>
                                            <div className="price-fake">原价:299</div>
                                        </div>
                                        <div className="price-right">xxx已售</div>
                                    </div>
                                </div>
                            </div>
                    )
                })}
            </div>
            ):""}
        </div>)
    }
}

ReactDOM.render(<App/>
    ,
    document.getElementById('root')
  )