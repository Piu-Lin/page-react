const ul = document.querySelector("ul")
    const title = document.querySelector("h1")
    Date.prototype.Format = function (fmt) { // author: meizz
        var o = {
            "M+": this.getMonth() + 1, // 月份
            "d+": this.getDate(), // 日
            "h+": this.getHours(), // 小时
            "m+": this.getMinutes(), // 分
            "s+": this.getSeconds(), // 秒
            "q+": Math.floor((this.getMonth() + 3) / 3), // 季度
            "S": this.getMilliseconds() // 毫秒
        };
        if (/(y+)/.test(fmt))
            fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
            if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
    }

    ul.addEventListener("click", function (e) {
        const dom = e.target
        if (dom.nodeName == "LI") {
            // alert(Array.from(ul.querySelectorAll('li')).indexOf(dom))
            switch (dom.innerText) {
                case "p1":
                    dom.style.color = "red"
                    break
                case "p2":
                    let Da = new Date().Format("yyyy-MM-dd");
                    title.innerText = Da
                case "p3":
                    dom.classList.add("fn-active");
                    break
                case "p4":
                    if (ul.lastElementChild.innerText == "p8")
                        ul.removeChild(ul.lastElementChild)
                    break
                case "p5":
                    window.open("https://www.taobao.com/")
                    break
                case "p6":
                    const p9 = document.createElement("li");
                    p9.innerText = "p9"
                    ul.append(p9)
                    break
                case "p7":
                    console.log(document.querySelector(".m-box"))
                    document.querySelector(".m-box").style.width = window.innerWidth
                    break

            }

        }
    })