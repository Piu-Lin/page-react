class App extends React.Component {
    state={
        picClass:"pic",
        navSty:[true, false, false],
        sqlList:[1,2,3],
        x:4
    }
    add=()=>{
        this.setState({sqlList:[...this.state.sqlList,this.state.x]})
        let x=this.state.x+1
        this.setState({x})
    }
    delete=(deleteValue)=>{
        let sqlList = this.state.sqlList //list数组
        sqlList.forEach((value, index)=>{
            if (value == deleteValue){
                sqlList.splice(index,1)
            }
        })
        this.setState({
            sqlList:sqlList  //删除后的数据给 list数组赋值
        })

    }
    render() {
        
        return(
        <div>
            <div className="nav">
                <div className={this.state.navSty[0]?"navItem active":"navItem"} onClick={()=>{this.setState({navSty:[true, false, false]})}}>第一个</div>
                <div className={this.state.navSty[1]?"navItem active":"navItem"} onClick={()=>{this.setState({navSty:[false, true, false]})}}>第二个</div>
                <div className={this.state.navSty[2]?"navItem active":"navItem"} onClick={()=>{this.setState({navSty:[false, false, true]})}}>第三个</div>
            </div>
            
            {this.state.navSty[0]==true?(
                <div>
                <img onClick={()=>{this.setState({picClass:"amplification"})}} className={this.state.picClass} src="https://mooc.hznu.edu.cn/static/media/logo_co.7bebcb03.svg" alt=""/>
                </div>
            ):""}
            {this.state.navSty[1]==true?(
                <div>
                上方导航栏已实现
                </div>
            ):""}
            {this.state.navSty[2]==true?(
                <div>
                {this.state.sqlList.map((value, index)=>{
                    return(
                        <div key={index} className="nav">
                            {value}
                            <input type="text"></input>
                            <div onClick={()=>{this.delete(value)}}>delete</div>
                        </div>
                    )
                })}
                <div onClick={()=>{this.add()}}>添加</div>
                </div>
            ):""}
        
        </div>
        )
    }
}

ReactDOM.render(<App/>,
    document.getElementById('root')
  )