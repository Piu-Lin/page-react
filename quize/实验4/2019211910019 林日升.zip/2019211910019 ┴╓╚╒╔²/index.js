const fBox = [
  {"title":"待收货","num":5},
  {"title":"待发货","num":0},
  {"title":"待付款","num":0},
  {"title":"待评价","num":1},
]
const sBox =["公告","规则","论坛","安全","公益"]
const tBox =["充话费","旅行","车险","游戏"]
const tsBox=["充话费","冲流量","冲固话","冲宽带"]
ReactDOM.render(
  <div className="main-box">
    <div className="f-box">
    {fBox.map((v,index)=>{
     return (
      <div key={index} className="f-item-box">
        <div className="num-item">
          {v.num}
        </div>
        <div className="title-item">
          {v.title}
        </div>
      </div>
     )
    })}
    </div>
    <div className="online-box">
      <div className="online-word">网上有害信息举报专区</div>
    </div>
    <div className="s-box">
      {sBox.map((v,index)=>{
        return (
          <div className="s-item" key={index}>
            <div>{v}</div>
          </div>
        )
      })}
    </div>
    <div className="lunt">
      <div className="f-lunt">
        <div>淘宝1212大促</div>
        <div>在线职业培训</div>
      </div>
      <div className="s-lunt">
        <div>金秋超值招商</div>
        <div>运营神器大促</div>
      </div>
    </div>
    <div className="t-box">
      {tBox.map((v,index)=>{
      return (
        <div key={index} className="f-item-box">
          <div className="num-item">
          </div>
          <div className="title-item">
            {v}
          </div>
        </div>
      )
      })}
    </div>
    <div className="ts-box">
      {tsBox.map((v,index)=>{
      return (
        <div key={index} className="f-item-box">
          <div className="num-item">
          </div>
          <div className="sub-title-item">
            {v}
          </div>
        </div>
      )
      })}
    </div>
      <form id="form">
        <input placeholder="请输入手机号码"></input>
        <br></br>
        <input></input>
        <div>售价￥ <span></span></div>
        <input className="sumint" type="submit" value="立即充值" ></input>
      </form>
  </div>,

document.getElementById('root')
)